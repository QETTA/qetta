# Changelog

## 2025-07-29

- Update to React 19 and Next.js 15.4

## 2025-05-14

- Initial release
